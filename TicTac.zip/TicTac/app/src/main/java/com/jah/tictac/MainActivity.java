package com.jah.tictac;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private boolean awinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        awinner = false;
    }

    // Button click, used for all buttons
    public void BuClick(View view) {
        // get the Button , which one was clicked
        Button buSelected = (Button) view;

        int cellid = 0;
        // get the button selected ID
        switch(buSelected.getId()){

            case R.id.bu1:
                cellid=1;
                break;
            case R.id.bu2:
                cellid=2;
                break;
            case R.id.bu3:
                cellid=3;
                break;
            case R.id.bu4:
                cellid=4;
                break;
            case R.id.bu5:
                cellid=5;
                break;
            case R.id.bu6:
                cellid=6;
                break;
            case R.id.bu7:
                cellid=7;
                break;
            case R.id.bu8:
                cellid=8;
                break;
            case R.id.bu9:
                cellid=9;
                break;
        }
        playGame(cellid, buSelected);
    }

    // 1 for first player, 2 for second player
    int activeplayer = 1;
    ArrayList<Integer> player1 = new ArrayList<>(); // hold player 1 data
    ArrayList<Integer> player2 = new ArrayList<>(); // hold player 2 data

    private void playGame(int cellid, Button buttonselected){

        Toast.makeText(this, "Player"+String.valueOf(cellid), Toast.LENGTH_SHORT).show();
        Log.d("player", String.valueOf(cellid));
        Log.d("Button Text: " , buttonselected.getText().toString());

        if(activeplayer == 1){
            buttonselected.setText("X");
            buttonselected.setBackgroundColor(Color.GREEN);
            player1.add(cellid);
            checkWinner();
            activeplayer = 2;
            if(!awinner) {
                AutoPlay();
            }else{
                stopgame();
            }
        }else if(activeplayer == 2){
            buttonselected.setText("O");
            buttonselected.setBackgroundColor(Color.BLUE);
            player2.add(cellid);
            checkWinner();
            if(awinner){
                stopgame();
            }
            activeplayer = 1;
        }

        // set the button to false, so it can't be used again
        buttonselected.setEnabled(false);

        // check for the Winner
        //checkWinner();
    }

    private void stopgame(){
        Button buSelected;
        // find empty cells
        for(int cell = 0; cell < 10; cell++){
            if( !( player1.contains(cell) || player2.contains(cell) ) ){
                //emptycells.add(cell);
                switch(cell){
                    case 1:
                        buSelected =(Button)findViewById(R.id.bu1);
                        buSelected.setEnabled(false);
                        break;
                    case 2:
                        buSelected =(Button)findViewById(R.id.bu2);
                        buSelected.setEnabled(false);
                        break;
                    case 3:
                        buSelected =(Button)findViewById(R.id.bu3);
                        buSelected.setEnabled(false);
                        break;
                    case 4:
                        buSelected =(Button)findViewById(R.id.bu4);
                        buSelected.setEnabled(false);
                        break;
                    case 5:
                        buSelected =(Button)findViewById(R.id.bu5);
                        buSelected.setEnabled(false);
                        break;
                    case 6:
                        buSelected =(Button)findViewById(R.id.bu6);
                        buSelected.setEnabled(false);
                        break;
                    case 7:
                        buSelected =(Button)findViewById(R.id.bu7);
                        buSelected.setEnabled(false);
                        break;
                    case 8:
                        buSelected =(Button)findViewById(R.id.bu8);
                        buSelected.setEnabled(false);
                        break;
                    case 9:
                        buSelected =(Button)findViewById(R.id.bu9);
                        buSelected.setEnabled(false);
                        break;

                }
            }
        }// end for loop
        Toast.makeText(this, "Game Ended", Toast.LENGTH_LONG).show();
    }

    // check for the winner
    private void checkWinner(){
        int winner = 0;
        // check the first row
        if(player1.contains(1) && player1.contains(2) && player1.contains(3)){
            winner = 1;
        }
        if(player2.contains(1) && player2.contains(2) && player2.contains(3)){
            winner = 2;
        }
        // check the second row
        if(player1.contains(4) && player1.contains(5) && player1.contains(6)){
            winner = 1;
        }
        if(player2.contains(4) && player2.contains(5) && player2.contains(6)){
            winner = 2;
        }

        // check third row
        if(player1.contains(7) && player1.contains(8) && player1.contains(9)){
            winner = 1;
        }
        if(player2.contains(7) && player2.contains(8) && player2.contains(9)){
            winner = 2;
        }

        // check the columns, first column
        if(player1.contains(1) && player1.contains(4) && player1.contains(7)){
            winner = 1;
        }
        if(player2.contains(1) && player2.contains(4) && player1.contains(7)){
            winner = 2;
        }

        // second columnn
        if(player1.contains(2) && player1.contains(5) && player1.contains(8)){
            winner = 1;
        }
        if(player2.contains(2) && player2.contains(5) && player2.contains(8)){
            winner = 2;
        }

        // third column
        if(player1.contains(3) && player1.contains(6) && player1.contains(9)){
            winner = 1;
        }
        if(player2.contains(3) && player2.contains(6) && player2.contains(9)){
            winner = 2;
        }

        // check the diagonals
        if(player1.contains(1) && player1.contains(5) && player1.contains(9)){
            winner = 1;
        }
        if(player2.contains(1) && player2.contains(5) && player2.contains(9)){
            winner = 2;
        }

        if(player1.contains(3) && player1.contains(5) && player1.contains(7)){
            winner = 1;
        }
        if(player2.contains(3) && player2.contains(5) && player2.contains(7)){
            winner = 2;
        }

        if(winner != 0){
            if(winner == 1){
                awinner = true;
                Toast.makeText(this, "Player 1 is the Winner", Toast.LENGTH_LONG).show();
            }else if(winner == 2){
                awinner = true;
                Toast.makeText(this, "Player 2 is the Winner", Toast.LENGTH_LONG).show();
            }
        }
    }

    // auto play, play against the computer
    private void AutoPlay(){
        // empty array list of cells
        ArrayList<Integer> emptycells = new ArrayList<>();

        // find empty cells
        for(int cell = 0; cell < 10; cell++){
            if( !( player1.contains(cell) || player2.contains(cell) ) ){
                emptycells.add(cell);
            }
        }

        // get a random cell, using random
        Random ran = new Random();
        // if size = 3, get 3 random number in (0,1,2)
        int ranindex = ran.nextInt(emptycells.size() - 0) + 0; // next random int
        int cellid = emptycells.get(ranindex); // now get the cell id from the empty cells


        // get the Button , which one was clicked
        Button buSelected ;

        // get the button selected ID
        switch(cellid){

            case 1:
                buSelected =(Button)findViewById(R.id.bu1);
                break;
            case 2:
                buSelected =(Button)findViewById(R.id.bu2);
                break;
            case 3:
                buSelected =(Button)findViewById(R.id.bu3);
                break;
            case 4:
                buSelected =(Button)findViewById(R.id.bu4);
                break;
            case 5:
                buSelected =(Button)findViewById(R.id.bu5);
                break;
            case 6:
                buSelected =(Button)findViewById(R.id.bu6);
                break;
            case 7:
                buSelected =(Button)findViewById(R.id.bu7);
                break;
            case 8:
                buSelected =(Button)findViewById(R.id.bu8);
                break;
            case 9:
                buSelected =(Button)findViewById(R.id.bu9);
                break;
            default:
                buSelected =(Button)findViewById(R.id.bu1);
                break;
        }
        playGame(cellid, buSelected);
    }
}